<?php
class fdDownloads extends xPDOSimpleObject {}