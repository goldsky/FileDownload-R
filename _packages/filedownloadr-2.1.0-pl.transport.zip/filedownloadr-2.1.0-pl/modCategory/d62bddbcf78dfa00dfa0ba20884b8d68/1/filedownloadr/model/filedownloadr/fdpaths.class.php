<?php
class fdPaths extends xPDOSimpleObject {}