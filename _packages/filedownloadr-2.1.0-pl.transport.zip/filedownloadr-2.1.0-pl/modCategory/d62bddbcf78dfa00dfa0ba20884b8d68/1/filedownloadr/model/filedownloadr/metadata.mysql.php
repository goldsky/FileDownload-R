<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'fdCount',
    1 => 'fdDownloads',
    2 => 'fdPaths',
  ),
);